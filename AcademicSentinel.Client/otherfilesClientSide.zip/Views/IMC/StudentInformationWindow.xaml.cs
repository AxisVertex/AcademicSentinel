using System.Windows;
using AcademicSentinel.Client.Models; // <-- ADD THIS LINE

namespace AcademicSentinel.Client.Views.IMC
{
    public partial class StudentInformationWindow : Window
    {
        private StudentListItem _student;
        private string _roomSection;

        // Backup values for cancel
        private string _backupName;
        private string _backupId;
        private string _backupYear;
        private string _backupCourse;

        public StudentInformationWindow(StudentListItem student, string roomSection)
        {
            InitializeComponent();

            _student = student;
            _roomSection = roomSection;

            // Populate fields in view mode
            TxtStudentName.Text = student.StudentName ?? "";
            TxtStudentId.Text = student.StudentId ?? "";
            TxtStudentYear.Text = student.StudentYear ?? "";
            TxtStudentCourse.Text = student.StudentCourse ?? "";
            TxtSection.Text = roomSection;

            // Start in View mode
            SetViewMode();
        }

        private void SetViewMode()
        {
            TxtStudentName.IsReadOnly = true;
            TxtStudentId.IsReadOnly = true;
            TxtStudentYear.IsReadOnly = true;
            TxtStudentCourse.IsReadOnly = true;

            if (BtnEdit != null) BtnEdit.Visibility = Visibility.Visible;
            if (BtnSaveChanges != null) BtnSaveChanges.Visibility = Visibility.Collapsed;
            if (BtnCancel != null) BtnCancel.Visibility = Visibility.Collapsed;
        }

        private void SetEditMode()
        {
            // Store backups
            _backupName = TxtStudentName.Text;
            _backupId = TxtStudentId.Text;
            _backupYear = TxtStudentYear.Text;
            _backupCourse = TxtStudentCourse.Text;

            TxtStudentName.IsReadOnly = false;
            TxtStudentId.IsReadOnly = false;
            TxtStudentYear.IsReadOnly = false;
            TxtStudentCourse.IsReadOnly = false;

            BtnEdit.Visibility = Visibility.Collapsed;
            BtnSaveChanges.Visibility = Visibility.Visible;
            BtnCancel.Visibility = Visibility.Visible;
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            SetEditMode();
        }

        private void BtnSaveChanges_Click(object sender, RoutedEventArgs e)
        {
            // Save changes back to the local UI model
            if (_student != null)
            {
                _student.StudentName = TxtStudentName.Text.Trim();
                _student.StudentId = TxtStudentId.Text.Trim();
                _student.StudentYear = TxtStudentYear.Text.Trim();
                _student.StudentCourse = TxtStudentCourse.Text.Trim();
            }

            MessageBox.Show("Student information updated locally!\n\n(Note: The Server's 'Users' table currently only stores Emails. To make Year/Course saves permanent, we will migrate the DB later.)",
                "Saved", MessageBoxButton.OK, MessageBoxImage.Information);

            // Switch back to view mode
            SetViewMode();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            // Restore backup values
            TxtStudentName.Text = _backupName;
            TxtStudentId.Text = _backupId;
            TxtStudentYear.Text = _backupYear;
            TxtStudentCourse.Text = _backupCourse;

            // Switch back to view mode
            SetViewMode();
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}