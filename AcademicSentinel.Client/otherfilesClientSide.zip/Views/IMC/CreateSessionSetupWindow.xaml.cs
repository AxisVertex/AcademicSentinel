﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Windows;
using AcademicSentinel.Client.Constants;
using AcademicSentinel.Client.Services;

namespace AcademicSentinel.Client.Views.IMC
{
    public partial class CreateSessionSetupWindow : Window
    {
        private int _currentRoomId;

        // UPDATED: Now requires RoomId!
        public CreateSessionSetupWindow(int roomId, string roomTitle)
        {
            InitializeComponent();
            _currentRoomId = roomId;
        }

        // Toggles the Idle Time textbox on and off
        private void ChkIdle_CheckedChanged(object sender, RoutedEventArgs e)
        {
            if (IdleTimePanel != null && ChkIdle != null)
            {
                bool isChecked = ChkIdle.IsChecked == true;
                IdleTimePanel.IsEnabled = isChecked;
                IdleTimePanel.Opacity = isChecked ? 1.0 : 0.5;
            }
        }

        private async void BtnStartSession_Click(object sender, RoutedEventArgs e)
        {
            // 1. Validate Idle Time if checked
            int idleSeconds = 0;
            if (ChkIdle.IsChecked == true)
            {
                if (!int.TryParse(TxtIdleSeconds.Text, out idleSeconds) || idleSeconds < 10)
                {
                    MessageBox.Show("Please enter a valid idle threshold in seconds (minimum 10).", "Invalid Input", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
            }

            // 2. Package the rules matching your Server's RoomDetectionSettings model
            var settingsPayload = new
            {
                EnableFocusDetection = ChkTabSwitch.IsChecked == true,
                EnableVirtualizationCheck = ChkVirtualMachine.IsChecked == true,
                EnableClipboardMonitoring = ChkClipboard.IsChecked == true,
                EnableProcessDetection = ChkProcess.IsChecked == true,
                EnableIdleDetection = ChkIdle.IsChecked == true,
                IdleThresholdSeconds = idleSeconds,
                StrictMode = ChkStrictMode.IsChecked == true
            };

            // 3. Send to Server
            BtnStartSession.IsEnabled = false;
            BtnStartSession.Content = "Saving...";

            try
            {
                using (var client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", SessionManager.JwtToken);

                    // Call the POST api/rooms/{roomId}/settings endpoint
                    var response = await client.PostAsJsonAsync($"{ApiEndpoints.Rooms}/{_currentRoomId}/settings", settingsPayload);

                    if (response.IsSuccessStatusCode)
                    {
                        MessageBox.Show("Session detection rules successfully saved to the database!", "Setup Complete", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.DialogResult = true; // Tell the previous window it was successful
                        this.Close();
                    }
                    else
                    {
                        string error = await response.Content.ReadAsStringAsync();
                        MessageBox.Show($"Failed to save rules.\n\nServer said: {error}", "API Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                        BtnStartSession.IsEnabled = true;
                        BtnStartSession.Content = "Save Rules & Continue";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Network Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                BtnStartSession.IsEnabled = true;
                BtnStartSession.Content = "Save Rules & Continue";
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}