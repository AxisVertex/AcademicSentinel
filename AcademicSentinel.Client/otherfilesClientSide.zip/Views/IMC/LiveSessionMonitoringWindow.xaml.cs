﻿using AcademicSentinel.Client.Constants;
using AcademicSentinel.Client.Services;
using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading; // NEW: Required for the Live Timer

namespace AcademicSentinel.Client.Views.IMC
{
    public partial class LiveSessionMonitoringWindow : Window
    {
        private HubConnection _hubConnection;
        private int _roomId;
        private int _totalAlerts = 0;
        private int _currentSessionId;

        // Timer Variables
        private DispatcherTimer _sessionTimer;
        private DateTime _sessionStartTime;

        private ICollectionView _studentsView;
        private ICollectionView _logsView;
        private LiveStudentStatus _selectedStudent;

        public ObservableCollection<LiveStudentStatus> ActiveStudents { get; set; }
        public ObservableCollection<LogEntry> LogFeed { get; set; }

        public LiveSessionMonitoringWindow(int roomId, string roomTitle)
        {
            InitializeComponent();
            _roomId = roomId;

            TxtRoomHeader.Text = $"Live Session Monitoring - {roomTitle}";
            TxtSessionId.Text = $"Session ID: Waiting...";

            if (SessionManager.CurrentUser != null)
                TxtProfName.Text = SessionManager.CurrentUser.Email.Split('@')[0];

            ActiveStudents = new ObservableCollection<LiveStudentStatus>();
            LogFeed = new ObservableCollection<LogEntry>();

            _studentsView = CollectionViewSource.GetDefaultView(ActiveStudents);
            _logsView = CollectionViewSource.GetDefaultView(LogFeed);

            // NEW: Auto-Sort Logic! 
            // 1st Priority: Most violations go to the top
            // 2nd Priority: Alphabetical by Email
            _studentsView.SortDescriptions.Add(new SortDescription("ViolationCount", ListSortDirection.Descending));
            _studentsView.SortDescriptions.Add(new SortDescription("Email", ListSortDirection.Ascending));

            StudentsItemsControl.ItemsSource = _studentsView;
            LogFeedItemsControl.ItemsSource = _logsView;
        }

        // ======================== SEARCH & FILTER LOGIC ========================

        private void TxtStudentSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            string filter = TxtStudentSearch.Text.ToLower();
            _studentsView.Filter = obj => string.IsNullOrEmpty(filter) || (obj as LiveStudentStatus).Email.ToLower().Contains(filter);
            _studentsView.Refresh();
        }

        private void CmbLogFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ApplyAllFilters();
        }

        private void ApplyAllFilters()
        {
            if (_logsView == null) return;

            string category = (CmbLogFilter.SelectedItem as ComboBoxItem)?.Content.ToString() ?? "All Entries";

            _logsView.Filter = obj =>
            {
                var entry = obj as LogEntry;
                bool matchesUser = _selectedStudent == null ||
                                   entry.StudentEmail == _selectedStudent.Email ||
                                   entry.StudentEmail == "SYSTEM";

                bool matchesCategory = true;
                if (category == "Violations Only") matchesCategory = entry.BadgeText == "VIOLATION";
                else if (category == "Connections Only") matchesCategory = (entry.BadgeText == "JOINED" || entry.BadgeText == "LEFT" || entry.BadgeText == "KICKED");

                return matchesUser && matchesCategory;
            };
            _logsView.Refresh();
        }

        private void BtnShowGlobalLogs_Click(object sender, RoutedEventArgs e)
        {
            _selectedStudent = null;
            TxtLogHeader.Text = "Global Log Feed";
            TxtSelectedName.Text = "Select a Student";
            ApplyAllFilters();
        }

        // ======================== SESSION & SIGNALR ========================

        private async void BtnStartMonitoring_Click(object sender, RoutedEventArgs e)
        {
            BtnStartMonitoring.IsEnabled = false;
            BtnStartMonitoring.Content = "Starting...";
            try
            {
                using var client = new HttpClient();
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", SessionManager.JwtToken);
                var response = await client.PostAsync($"{ApiEndpoints.Rooms}/{_roomId}/start-session", null);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadFromJsonAsync<StartSessionResponse>();
                    _currentSessionId = result.SessionId;
                    TxtSessionId.Text = $"Session ID: {_currentSessionId}";
                    await InitializeSignalR();

                    BtnStartMonitoring.Visibility = Visibility.Collapsed;
                    TimerPanel.Visibility = Visibility.Visible; // Show the timer
                    StartSessionTimer(); // Start the clock!

                    LogActivity("SYSTEM", "STARTED", "Live monitoring active.", "#1B5E20");
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        // NEW: Timer Method
        private void StartSessionTimer()
        {
            _sessionStartTime = DateTime.Now;
            _sessionTimer = new DispatcherTimer();
            _sessionTimer.Interval = TimeSpan.FromSeconds(1);
            _sessionTimer.Tick += (s, e) =>
            {
                var elapsed = DateTime.Now - _sessionStartTime;
                TxtSessionTimer.Text = $"Duration: {elapsed:hh\\:mm\\:ss}";
            };
            _sessionTimer.Start();
        }

        private async Task InitializeSignalR()
        {
            _hubConnection = new HubConnectionBuilder()
                .WithUrl($"{ApiEndpoints.BaseUrl}/monitoringHub", o => o.AccessTokenProvider = () => Task.FromResult(SessionManager.JwtToken))
                .WithAutomaticReconnect().Build();

            _hubConnection.On<int>("StudentJoined", (id) => Dispatcher.Invoke(() => {
                ActiveStudents.Add(new LiveStudentStatus { Email = $"student_{id}@feutech.edu", Status = "Connected", StatusColor = "#4CAF50" });
                LogActivity($"student_{id}@feutech.edu", "JOINED", "Connected to session.", "#4CAF50");
                UpdateParticipantCount();
                _studentsView.Refresh(); // Refresh sort order
            }));

            try { await _hubConnection.StartAsync(); await _hubConnection.InvokeAsync("JoinRoom", _roomId.ToString()); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LogActivity(string email, string badge, string msg, string color)
        {
            if (EmptyLogFeedState != null) EmptyLogFeedState.Visibility = Visibility.Collapsed;
            LogFeed.Insert(0, new LogEntry { Timestamp = DateTime.Now.ToString("T"), StudentEmail = email, BadgeText = badge, BadgeColor = color, Message = msg });
        }

        private void UpdateParticipantCount()
        {
            if (EmptyParticipantsState != null && ActiveStudents.Count > 0) EmptyParticipantsState.Visibility = Visibility.Collapsed;
            TxtParticipantCount.Text = $"{ActiveStudents.Count} Connected";
        }

        // ======================== UI ACTIONS ========================

        private void ParticipantRow_Click(object sender, MouseButtonEventArgs e)
        {
            _selectedStudent = (sender as Border)?.DataContext as LiveStudentStatus;
            if (_selectedStudent != null)
            {
                TxtSelectedName.Text = _selectedStudent.Email.Split('@')[0];
                TxtSelectedStatus.Text = _selectedStudent.Status.ToUpper();
                SelectedStatusDot.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString(_selectedStudent.StatusColor));
                TxtAlertCount.Text = _selectedStudent.ViolationCount.ToString();

                TxtRiskLevel.Text = _selectedStudent.ViolationCount > 3 ? "DANGER" : (_selectedStudent.ViolationCount > 0 ? "WARNING" : "SAFE");
                TxtRiskLevel.Foreground = _selectedStudent.ViolationCount > 3 ? Brushes.Red : (_selectedStudent.ViolationCount > 0 ? Brushes.Orange : Brushes.Green);

                TxtLogHeader.Text = $"Logs: {_selectedStudent.Email.Split('@')[0]}";
                ApplyAllFilters();
            }
        }

        private void BtnRemoveFromSession_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedStudent == null) return;
            LogActivity(_selectedStudent.Email, "KICKED", "Instructor removed student.", "#D32F2F");
            ActiveStudents.Remove(_selectedStudent);
            BtnShowGlobalLogs_Click(null, null);
            UpdateParticipantCount();
        }

        private async void BtnEndSession_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("End session?", "Confirm", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                if (_currentSessionId > 0)
                {
                    using var client = new HttpClient();
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", SessionManager.JwtToken);
                    await client.PutAsync($"{ApiEndpoints.Rooms}/sessions/{_currentSessionId}/end", null);
                }
                _sessionTimer?.Stop(); // Stop timer
                this.Close();
            }
        }

        protected override async void OnClosing(CancelEventArgs e)
        {
            if (BtnStartMonitoring.Visibility == Visibility.Collapsed)
            {
                if (_currentSessionId > 0)
                {
                    try
                    {
                        using var client = new HttpClient();
                        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", SessionManager.JwtToken);
                        await client.PutAsync($"{ApiEndpoints.Rooms}/sessions/{_currentSessionId}/end", null);
                    }
                    catch { }
                }
                if (_hubConnection != null) await _hubConnection.StopAsync();
                _sessionTimer?.Stop(); // Stop timer
            }
            base.OnClosing(e);
        }

        private void StudentDropdown_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && btn.ContextMenu != null) { btn.ContextMenu.PlacementTarget = btn; btn.ContextMenu.IsOpen = true; }
        }

        // ======================== MOCK DATA INJECTOR ========================

        private void BtnInjectMockData_Click(object sender, RoutedEventArgs e)
        {
            ActiveStudents.Add(new LiveStudentStatus { Email = "joe@tech.edu", Status = "Connected", StatusColor = "#4CAF50" });
            ActiveStudents.Add(new LiveStudentStatus { Email = "jane@tech.edu", Status = "ALERT: ALT_TAB", StatusColor = "#D32F2F", ViolationCount = 2 });
            ActiveStudents.Add(new LiveStudentStatus { Email = "adam@tech.edu", Status = "Connected", StatusColor = "#4CAF50" });

            LogActivity("joe@tech.edu", "JOINED", "Student joined.", "#4CAF50");
            LogActivity("jane@tech.edu", "VIOLATION", "ALT_TAB detected.", "#D32F2F");
            LogActivity("adam@tech.edu", "JOINED", "Student joined.", "#4CAF50");

            UpdateParticipantCount();

            // Notice how Jane automatically goes to the top because she has 2 violations!
            _studentsView.Refresh();
            ApplyAllFilters();
        }

        public class StartSessionResponse { public int SessionId { get; set; } }
    }

    public class LiveStudentStatus : INotifyPropertyChanged
    {
        private string _status, _statusColor;
        private int _violations;
        public string Email { get; set; }
        public string Status { get => _status; set { _status = value; OnPropertyChanged(); } }
        public string StatusColor { get => _statusColor; set { _statusColor = value; OnPropertyChanged(); } }
        public int ViolationCount { get => _violations; set { _violations = value; OnPropertyChanged(); } }
        public bool HasViolation => ViolationCount > 0;
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([System.Runtime.CompilerServices.CallerMemberName] string n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
    }

    public class LogEntry { public string Timestamp { get; set; } public string StudentEmail { get; set; } public string BadgeText { get; set; } public string BadgeColor { get; set; } public string Message { get; set; } }
}