﻿using System;
using System.Windows;
using System.Windows.Input;
using System.Text.RegularExpressions;
using AcademicSentinel.Client.Services;
using AcademicSentinel.Client.Models;

namespace AcademicSentinel.Client.Views.Shared
{
    public partial class RegisterWindow : Window
    {
        private readonly AuthService _authService;

        public RegisterWindow()
        {
            InitializeComponent();
            _authService = new AuthService(); // Initialize our service
        }

        // 1. Allows dragging the borderless window (Fixes UI issue)
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        private async void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            // Grab data from the UI
            string email = TxtRegEmail.Text.Trim();
            string password = TxtRegPassword.Password;
            string confirmPassword = TxtRegConfirmPassword.Password;

            // 2. Basic Empty Validation
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please fill in all required fields.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 3. Strict Email Validation
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";
            if (!Regex.IsMatch(email, emailPattern))
            {
                MessageBox.Show("Please enter a valid email address format (e.g., teacher@feutech.edu).", "Invalid Email", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtRegEmail.Focus();
                return;
            }

            // 4. Password Match Validation
            if (password != confirmPassword)
            {
                MessageBox.Show("Passwords do not match. Please re-type carefully.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtRegConfirmPassword.Clear();
                TxtRegConfirmPassword.Focus();
                return;
            }

            // 5. Password Length Validation
            if (password.Length < 6)
            {
                MessageBox.Show("Password must be at least 6 characters long for security.", "Weak Password", MessageBoxButton.OK, MessageBoxImage.Warning);
                TxtRegPassword.Focus();
                return;
            }

            // 6. Determine Role from Radio Buttons (FIXED TYPO HERE)
            string selectedRole = RbTeacher.IsChecked == true ? "Instructor" : "Student";

            // Enforce IMC Focus
            if (selectedRole == "Student")
            {
                MessageBox.Show("Student registration is currently disabled while we focus on building the Instructor Monitoring Console.", "IMC Focus Mode", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Package the data for the Server (FIXED MISSING FULLNAME HERE)
            var registerData = new UserRegisterDto
            {
                // Use the first part of the email as their name temporarily until you add a Name textbox
                FullName = email.Split('@')[0],
                Email = email,
                Password = password,
                Role = selectedRole
            };

            // UI Feedback
            BtnRegister.IsEnabled = false;
            BtnRegister.Content = "Creating Account...";

            // Send to Server
            bool isSuccess = await _authService.RegisterAsync(registerData);

            if (isSuccess)
            {
                MessageBox.Show("Registration successful! You can now log in.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                // Route to login window
                LoginWindow loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Registration failed. This email might already be taken, or the server is unavailable.", "Registration Error", MessageBoxButton.OK, MessageBoxImage.Error);
                BtnRegister.IsEnabled = true;
                BtnRegister.Content = "Create Account";
            }
        }

        // 7. Fixes the Close "X" Button
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        // 8. Fixes the "Log in here" link at the bottom
        private void LinkLoginHere_Click(object sender, MouseButtonEventArgs e)
        {
            LoginWindow loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }

        private void RoleToggle_Changed(object sender, RoutedEventArgs e)
        {
            // Left empty intentionally. We are enforcing the Teacher role anyway.
        }
    }
}