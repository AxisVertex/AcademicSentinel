using System;
using System.Windows;
using System.Windows.Input;
using AcademicSentinel.Client.Services;
using AcademicSentinel.Client.Views.IMC; // Needed to open the TeacherDashboard

namespace AcademicSentinel.Client.Views.Shared
{
    public partial class LoginWindow : Window
    {
        private readonly AuthService _authService;

        public LoginWindow()
        {
            InitializeComponent();
            _authService = new AuthService(); // Initialize our service
        }

        // Allows dragging the borderless window
        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        private async void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            // 1. Get exact text from the XAML variables
            string email = TxtLoginEmail.Text.Trim();
            string password = TxtLoginPassword.Password;

            // 2. Validate input
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter your email and password.", "Validation", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 3. UI Feedback during server call
            BtnLogin.IsEnabled = false;
            BtnLogin.Content = "Logging in...";

            try
            {
                // 4. Call your specific AuthService method
                // Note: AuthService.LoginAsync automatically populates the static SessionManager on success!
                bool isSuccess = await _authService.LoginAsync(email, password);

                if (isSuccess && SessionManager.IsLoggedIn)
                {
                    // 5. Check if the user is an Instructor (IMC Focus)
                    if (SessionManager.CurrentUser.Role.Equals("Instructor", StringComparison.OrdinalIgnoreCase))
                    {
                        // Open the Teacher Dashboard
                        TeacherDashboard dashboard = new TeacherDashboard();
                        dashboard.Show();

                        // Close the login window
                        this.Close();
                    }
                    else
                    {
                        // If a student tries to log in right now, we block them since we are focusing on IMC
                        MessageBox.Show("Student login is currently disabled while we focus on the Instructor Monitoring Console.", "IMC Focus Mode", MessageBoxButton.OK, MessageBoxImage.Information);
                        SessionManager.Logout(); // Clear the static session
                        ResetLoginButton();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid email or password.", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    ResetLoginButton();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unable to connect to the server. Please ensure AcademicSentinel.Server is running.\n\nError: {ex.Message}", "Connection Error", MessageBoxButton.OK, MessageBoxImage.Error);
                ResetLoginButton();
            }
        }

        // Helper to reset the button if login fails
        private void ResetLoginButton()
        {
            TxtLoginPassword.Clear();
            BtnLogin.IsEnabled = true;
            BtnLogin.Content = "Log In";
        }

        // Closes the entire application
        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        // Navigates to the Registration Window
        private void LinkCreateAccount_Click(object sender, RoutedEventArgs e)
        {
            RegisterWindow registerWindow = new RegisterWindow();
            registerWindow.Show();
            this.Close();
        }

        // Triggered when switching between Student/Teacher radio buttons.
        // Left empty intentionally as we are enforcing the Teacher role in the login logic anyway.
        private void RoleToggle_Changed(object sender, RoutedEventArgs e)
        {

        }
    }
}